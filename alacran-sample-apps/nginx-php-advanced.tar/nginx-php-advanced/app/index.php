<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<p>Hello Alacran</p>'; ?> 
 </body>
</html>

