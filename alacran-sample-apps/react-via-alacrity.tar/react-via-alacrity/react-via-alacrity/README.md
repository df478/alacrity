This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## AlaCrity files

The following files are added to make Create React App work with AlaCrity:

- `alacran-definition`
- `Dockerfile`
- `default.conf`
